const express = require('express')
const router = express.Router()

const vehicleController = require("../controller/VehicleController")

router.get("/", vehicleController.get)
router.post("/", vehicleController.save)

module.exports = router