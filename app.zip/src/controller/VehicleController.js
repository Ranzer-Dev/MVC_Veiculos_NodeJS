const VehicleModel = require('../models/VehicleModel')
const vehicle = new VehicleModel()

exports.get = (req, resp) => {
  var result = vehicle.GetAll();
  resp.render("homeView", { vehicle: result });    
}

exports.save = (req, resp) => {
  // var result = vehicle.Save(req.body.nome, req.body.id);
  // resp.render("homeView", { saved: true });
  console.log(req)
};